# (c) 2021 JOHN POWELL

# this is my secret stash of code goodness

#  blah blah
import mylocalmod

print("Hello")